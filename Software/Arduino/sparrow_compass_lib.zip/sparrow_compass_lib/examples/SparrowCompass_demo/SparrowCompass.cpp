#include "./SparrowCompass.h"

SparrowCompass::SparrowCompass(){
  hw_init();
}