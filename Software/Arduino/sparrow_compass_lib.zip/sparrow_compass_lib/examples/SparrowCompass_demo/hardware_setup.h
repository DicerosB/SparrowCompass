#include <Arduino.h>

void hw_init();
static void MX_GPIO_Init(void);
static void MX_I2C1_Init(void);
void SystemClock_Config(void);

